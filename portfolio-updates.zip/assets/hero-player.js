import '/music-player/player.js';

const player = document.createElement('vinyl-player');
player.className = 'portfolio-hero-player';
player.setAttribute('src', '/music-player/you-are-my-defense.m4a');
player.setAttribute('title', 'You Are My Defense');
player.setAttribute('artist', 'Christa Wells');
player.setAttribute('cover', '/music-player/feed-your-soul-cover.jpg');

const compactSlot = document.createElement('div');
compactSlot.className = 'portfolio-player-section';

const musicGuide = document.createElement('div');
musicGuide.className = 'portfolio-music-guide';
musicGuide.setAttribute('aria-hidden', 'true');
musicGuide.innerHTML = '<span>和你分享我喜欢的音乐</span>';

function syncMusicGuideArrow() {
  const original = document.querySelector('#about [data-framer-name="Drag pills"]')
    ?.previousElementSibling?.querySelector('svg');
  if (!original) return;

  let arrow = musicGuide.querySelector('.portfolio-music-guide-arrow');
  if (!arrow) {
    arrow = document.createElement('div');
    arrow.className = 'portfolio-music-guide-arrow';
    musicGuide.append(arrow);
  }
  const originalUse = original.querySelector('use');
  const guideUse = arrow.querySelector('use');
  if (!guideUse || guideUse.getAttribute('href') !== originalUse?.getAttribute('href')) {
    arrow.replaceChildren(original.cloneNode(true));
  }
}

function placePlayer() {
  if (window.matchMedia('(min-width: 810px)').matches) {
    const hero = document.querySelector('section.framer-1wuhxx4') || document.getElementById('hero');
    if (!hero) return;
    if (player.parentElement !== hero) hero.append(player);
    if (musicGuide.parentElement !== hero) hero.append(musicGuide);
    syncMusicGuideArrow();
    compactSlot.remove();
    return;
  }

  const hero = document.getElementById('hero');
  if (!hero) return;
  musicGuide.remove();
  if (player.parentElement !== compactSlot) compactSlot.append(player);
  if (compactSlot.previousElementSibling !== hero) hero.after(compactSlot);
}

const adPilotCard = 'a.framer-qSCOv:is(.framer-v-1cvlh82, .framer-v-14w0ujp)';
const adPilotPage = '/dd/';

function updateRecentProjectCard() {
  const title = '星投 AdPilot 智能平台项目复盘（AI Agent项目）';
  document.querySelectorAll(adPilotCard).forEach((link) => {
    if (link.getAttribute('href') !== adPilotPage) link.setAttribute('href', adPilotPage);
    link.removeAttribute('target');
    const caption = link.querySelector('.framer-1pnyb87 p');
    if (caption && caption.textContent !== title) caption.textContent = title;
  });
}

const gamePlatformCard = 'a:is(.framer-v-5jcrqz, .framer-v-gcnegr)';
const gamePlatformPage = '/design-highlights/';

function updateGamePlatformLinks() {
  document.querySelectorAll(gamePlatformCard).forEach((link) => {
    if (link.getAttribute('href') !== gamePlatformPage) link.setAttribute('href', gamePlatformPage);
    link.removeAttribute('target');
  });
}

function placeHeroDetails() {
  placePlayer();
  updateRecentProjectCard();
  updateGamePlatformLinks();
}

window.addEventListener('load', () => {
  placeHeroDetails();
  new MutationObserver(placeHeroDetails).observe(document.getElementById('main') || document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['href', 'target'],
  });
  window.addEventListener('resize', placeHeroDetails, { passive: true });
}, { once: true });

const resumeLinks = 'a:is(.framer-m84oeb.framer-7p2yoh, .framer-9csKX.framer-wxs6d)';
const resumePage = '/resume/';

function restoreResumeLinks() {
  document.querySelectorAll(resumeLinks).forEach((link) => {
    if (link.getAttribute('href') !== resumePage) link.setAttribute('href', resumePage);
  });
}

restoreResumeLinks();
new MutationObserver(restoreResumeLinks).observe(document.getElementById('main') || document.body, {
  childList: true,
  subtree: true,
  attributes: true,
  attributeFilter: ['href'],
});

// The resume preview and project pages are outside Framer's router.
document.addEventListener('click', (event) => {
  const projectButton = event.target instanceof Element && event.target.closest('a.framer-gpG28.framer-1re3rej');
  if (projectButton) {
    const section = [...document.querySelectorAll('#recent-works, #recent-works-1')]
      .find((element) => element.getClientRects().length);
    event.preventDefault();
    event.stopPropagation();
    section?.scrollIntoView();
    return;
  }
  const resumeLink = event.target instanceof Element && event.target.closest(resumeLinks);
  if (resumeLink) {
    restoreResumeLinks();
    event.stopPropagation();
    if (event.button === 0 && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey) {
      event.preventDefault();
      window.location.assign(resumePage);
    }
    return;
  }
  if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
  const link = event.target instanceof Element && event.target.closest(
    `${gamePlatformCard}, ${adPilotCard}, a[href="/ad-management/"]`,
  );
  if (!link) return;
  event.preventDefault();
  event.stopPropagation();
  if (link.matches(adPilotCard)) {
    window.location.assign(adPilotPage);
    return;
  }
  window.location.assign(link.matches(gamePlatformCard) ? gamePlatformPage : link.href);
}, { capture: true });

const heroMouseMotion = window.matchMedia(
  '(hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)',
);
let movingHero;

function resetHeroMouseMotion() {
  movingHero?.style.removeProperty('--hero-mouse-x');
  movingHero?.style.removeProperty('--hero-mouse-y');
  movingHero = undefined;
}

document.addEventListener('pointermove', (event) => {
  if (!heroMouseMotion.matches || event.pointerType !== 'mouse') return;
  const hero = event.target instanceof Element && event.target.closest('section.framer-1wuhxx4, #hero');
  if (hero !== movingHero) resetHeroMouseMotion();
  if (!hero) return;

  movingHero = hero;
  const bounds = hero.getBoundingClientRect();
  const x = Math.max(-1, Math.min(1, 2 * (event.clientX - bounds.left) / bounds.width - 1));
  const y = Math.max(-1, Math.min(1, 2 * (event.clientY - bounds.top) / bounds.height - 1));
  hero.style.setProperty('--hero-mouse-x', `${x * 18}px`);
  hero.style.setProperty('--hero-mouse-y', `${y * 14}px`);
}, { passive: true });

document.documentElement.addEventListener('pointerleave', resetHeroMouseMotion);
window.addEventListener('blur', resetHeroMouseMotion);
heroMouseMotion.addEventListener('change', resetHeroMouseMotion);
